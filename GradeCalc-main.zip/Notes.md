## TODOs
- [ ] 

## Ideen
- GUI mit Tkinter oder PyQt?
- Bei Deine_module zeile: 77. Ein alle Noten löschen knopf machen!
- 

## Bugs
- 
- 
- 
- 
- 